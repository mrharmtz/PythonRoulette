#ifdef __cplusplus
extern "C" {
#endif

    void* roulette_init();
    void roulette_free(void* roulette);
    void roulette_insert(void* roulette,void* obj,double chance);
    void* roulette_roll(void* roulette);
    size_t roulette_size(void* roulette);
    void* roulette_init_iterator(void* roulette);
    void roulette_free_iterator(void* roulette_iterator);
    char roulette_iterator_hasNext(void* roulette, void* roulette_iterator);
    void* roulette_deref_iterator(void* roulette_iterator);
    void roulette_iterator_adv(void* roulette_iterator);

#ifdef __cplusplus
}
#endif
