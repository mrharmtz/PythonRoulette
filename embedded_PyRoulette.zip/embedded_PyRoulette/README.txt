author: mrharmtz

tested on windows using the mingw64 compiler, 
due to issues with mingw compiler and Python.h(https://bugs.python.org/issue11566) not playing nice, 
had to make a workaround 